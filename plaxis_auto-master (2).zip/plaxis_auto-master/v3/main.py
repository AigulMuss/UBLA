import datetime
import sys
from pathlib import Path
from typing import Optional, Self, Any, Literal

import matplotlib.pyplot as plt
import more_itertools as mit
import numpy as np
import optuna
import pandas as pd
import shapely.affinity as shaff
import shapely.geometry as shg
import shapely.ops as shops
from loguru import logger
from optuna import Trial
from optuna.trial import FixedTrial
from pydantic import BaseModel, ConfigDict, Field
from shapely.ops import split
from shapely.plotting import plot_line, plot_polygon, plot_points

from v1.geom_utils import get_elongated, log_spiral, get_line_xy, get_fitted_points, \
    get_xy, get_bottom_line
from v1.log_spiral_geometry import get_velocities, get_energy_dissipation
from v2.main import Surface, get_slope_tangent, big_num, colors

_colors = iter(colors)

pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', 40)


def _extract_polygons(shapely_geom) -> list[shg.Polygon]:
    match shapely_geom:
        case shg.Polygon():
            return [shapely_geom]
        case shg.MultiPolygon(geoms=geoms):
            return geoms
        case shg.GeometryCollection(geoms=geoms):
            return sum(list(map(_extract_polygons, geoms)), start=[])
        case shg.Point() | shg.LineString():
            return []
        case _:
            raise NotImplementedError(shapely_geom)


def get_slices_by_points(geom: shg.Polygon) -> list[shg.Polygon]:
    return list(mit.flatten([
        _extract_polygons(shg.box(x1, -big_num, x2, big_num).intersection(geom))
        for x1, x2 in mit.windowed(sorted(np.unique(get_xy(geom)[:, 0])), 2)
    ]))


def get_external_work(
        geom: shg.Polygon,
        phita: float,
        gamma: float,
        velocity: float,
) -> float:
    external_work = []
    # plot_polygon(geom, color=next(_colors))
    for slice_geom in get_slices_by_points(geom):
        # plot_polygon(slice_geom, color=next(_colors))
        slope_angle = np.arctan(get_slope_tangent(get_bottom_line(slice_geom)))
        external_work.append(
            gamma *
            velocity *
            slice_geom.area *
            abs(np.sin(slope_angle - phita))
        )

    return np.array(external_work).sum()


def get_normal(line: shg.LineString, point: shg.Point,
               x_offset: float) -> shg.LineString:
    normal_tangent = -1 / get_slope_tangent(line)
    xs = np.array([-x_offset, x_offset]) + point.x
    ys = get_line_points(normal_tangent, point, xs)
    return shg.LineString(np.stack([xs, ys], axis=-1))


def get_line_points(m, point: shg.Point, xs: np.ndarray | float):
    return m * (xs - point.x) + point.y


def spiral_xy(p0_x: float, p0_y: float, theta_x: float, rx: float):
    return np.stack([
        p0_x + rx * np.cos(theta_x),
        p0_y + rx * np.sin(theta_x),
    ], axis=-1)


def get_log_spiral_failure_curve_raw(
        origin: shg.Point,
        start: shg.Point,
        phita: float,
        num: int = 20,
) -> shg.LineString:
    toe_theta = np.arctan(get_slope_tangent(shg.LineString([start, origin])))
    toe_radius = start.distance(origin)
    R0 = toe_radius * np.exp(-(toe_theta - 0) * np.tan(phita))
    theta_x = np.linspace(toe_theta, np.pi / 2, num, True)
    Rx = log_spiral(R0, 0, theta_x, phita=phita)
    return shg.LineString(spiral_xy(origin.x, origin.y, theta_x, Rx))


def get_log_spiral_and_point(
        origin: shg.Point,
        start: shg.Point,
        end: shg.LineString,
        phita: float,
        num: int = 50,
) -> tuple[shg.LineString, shg.Point]:
    failure_curve = get_log_spiral_failure_curve_raw(origin, start, phita, num=num)
    endpoint: shg.Point = failure_curve.intersection(end)
    return split(failure_curve, end).geoms[0], endpoint


def get_linear_and_point(
        start: shg.Point,
        end: shg.LineString,
        angle: float,
) -> tuple[shg.LineString, shg.Point]:
    xs = np.array([start.x, big_num])
    ys = get_line_points(np.tan(angle), start, xs)
    failure_curve = shg.LineString(np.stack([xs, ys], axis=-1))
    endpoint: shg.Point = failure_curve.intersection(end)
    return split(failure_curve, end).geoms[0], endpoint


class Curve(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    end_line: shg.LineString

    start: Optional[shg.Point] = None
    end_point: Optional[shg.Point] = None

    line: Optional[shg.LineString] = None

    def model_post_init(self, __context: Any) -> None:
        if self.start is not None:
            self(self.start)

    def __call__(self, start: shg.Point) -> Self:
        return self

    def setup(self, start: shg.Point, failure_curve: shg.LineString):
        self.start = start

        self.end_point = failure_curve.intersection(self.end_line)

        try:
            self.line = get_split(failure_curve, self.end_line)
        except:
            # plot_points(self.start)
            # plot_line(self.end_line)
            # plot_line(failure_curve)
            # plot_points(self.end_point)
            # plt.show()
            raise

        return self

    def plot(self):
        plot_line(self.line, color=next(_colors))
        return self


def get_split(geom, splitter, ret_lower=True):
    g1, g2 = split(geom, splitter).geoms
    if g1.centroid.y > g2.centroid.y:
        return g2 if ret_lower else g1
    else:
        return g1 if ret_lower else g2


class LogSpiralCurve(Curve):
    origin: shg.Point
    phita: float
    num_points: int = 100

    def __call__(self, start: shg.Point) -> Self:
        failure_curve = get_log_spiral_failure_curve_raw(self.origin, start, self.phita,
                                                         num=self.num_points)
        return self.setup(start, failure_curve)


class LinearCurve(Curve):
    angle: float
    end_x: float

    def __call__(self, start: shg.Point) -> Self:
        xs = np.array([start.x, self.end_x])
        ys = get_line_points(np.tan(self.angle), start, xs)
        failure_curve = shg.LineString(np.stack([xs, ys], axis=-1))
        return self.setup(start, failure_curve)


class PolynomialCurve(LinearCurve):
    degree: int = 2
    depth: float
    num_points: int = 100
    side: Literal['left', 'right'] = 'right'

    def __call__(self, start: shg.Point) -> Self:
        super().__call__(start)
        angle = np.arctan(get_slope_tangent(self.line))
        # logger.debug("angle:\n{}", angle)
        # plot_line(self.line)
        line_h = shaff.rotate(self.line, -angle, origin=start, use_radians=True)
        # plot_line(line_h)
        midway = line_h.parallel_offset(self.depth, self.side).centroid
        # plot_points(midway, color='red')
        xy = get_line_xy(shg.LineString([start, midway, line_h.interpolate(1, True)]))
        curve_h = shg.LineString(get_fitted_points(xy, self.degree, self.num_points))
        # plot_line(curve_h)
        failure_curve = shaff.rotate(curve_h, angle, origin=start, use_radians=True)
        # plot_line(failure_curve)
        return self.setup(start, get_elongated(failure_curve))


def convert_enclosed_area_to_polygon(lines: list[shg.LineString],
                                     buffer_size: float = 1e-3) -> shg.Polygon:
    """https://gis.stackexchange.com/questions/420755/convert-area-between-linestrings-to-polygon-in-shapely"""
    union_result = shops.unary_union(lines).buffer(buffer_size)
    geoms = [shg.Polygon(x) for x in union_result.interiors]
    biggest_geom = max(geoms, key=lambda g: g.area)
    return shg.Polygon(biggest_geom).buffer(buffer_size, join_style='mitre')


class Case(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    phita: float  # radians
    soil_params: dict
    vs: dict = Field(default_factory=dict)
    surface: Surface
    origins: dict[str, shg.Point] = Field(default_factory=list)
    normals: list[shg.LineString] = Field(default_factory=list)
    failure_curves: list = Field(default_factory=list)
    partitions: list = Field(default_factory=list)
    blocks: list[shg.Polygon] = Field(default_factory=list)

    def model_post_init(self, __context: Any) -> None:
        self.vs = get_velocities(soil_1=self.soil_params, soil_2=self.soil_params)

    def set_normals(self, ratios: list[float]) -> Self:
        self.normals = [
            get_normal(
                self.surface.slope_line,
                point=self.surface.slope_line.interpolate(ratio, True),
                x_offset=3
            )
            for ratio in ratios
        ]
        return self

    def set_failure_curves(self, failure_curves: list[Curve], toe_offset: float):
        self.failure_curves = failure_curves

        start = shaff.translate(self.surface.toe, xoff=toe_offset)
        for curve in self.failure_curves:
            curve(start=start)  # .plot()
            start = curve.end_point
        return self

    def set_partitions(self, partitions: list[Curve]):
        self.partitions = partitions
        return self

    def create_blocks(self):
        self.blocks = [
            convert_enclosed_area_to_polygon([
                self.failure_curves[0].line,
                self.partitions[0].line,
                self.surface.linestring,
            ]),

            convert_enclosed_area_to_polygon([
                self.failure_curves[1].line,
                self.partitions[0].line,
                self.surface.linestring,
                self.partitions[1].line,
            ]),

            convert_enclosed_area_to_polygon([
                self.failure_curves[2].line,
                self.partitions[1].line,
                self.surface.linestring,
            ])
        ]
        # plot_polygon(blocks_1, color='green')
        # plot_polygon(blocks_2, color='orange')
        # plot_polygon(blocks_3, color='blue')
        return self

    energy_dissipation: Optional[float] = None

    def calculate_energy_dissipation(self) -> float:
        dissipation_energies = [
            get_energy_dissipation(
                self.failure_curves[0].line,
                cohesion=self.soil_params['cohesion'],
                phita=self.phita,
                velocity=self.vs['a'],
            ),
            get_energy_dissipation(
                self.failure_curves[1].line,
                cohesion=self.soil_params['cohesion'],
                phita=self.phita,
                velocity=self.vs['b'],
            ),
            get_energy_dissipation(
                self.failure_curves[2].line,
                cohesion=self.soil_params['cohesion'],
                phita=self.phita,
                velocity=self.vs['c'],
            ),
            get_energy_dissipation(
                self.partitions[0].line,
                cohesion=self.soil_params['cohesion'],
                phita=self.phita,
                velocity=self.vs['ab'],
            ),
            get_energy_dissipation(
                self.partitions[1].line,
                cohesion=self.soil_params['cohesion'],
                phita=self.phita,
                velocity=self.vs['bc'],
            ),
        ]

        self.energy_dissipation = sum(dissipation_energies)
        return self.energy_dissipation

    external_work: Optional[float] = None

    def calculate_external_work(self):
        self.external_work = np.array([
            get_external_work(
                part,
                phita=self.phita,
                gamma=self.soil_params['gamma'],
                velocity=self.vs[name])
            for name, part in zip(['a', 'b', 'c'], self.blocks)
        ]).sum()
        return self.external_work

    def get_h_critical(self):
        lower_curve = self.failure_curves[0]
        y_min = get_line_xy(lower_curve.line)[:, 1].min()
        # logger.debug("y_min:\n{}", y_min)
        upper_curve = self.failure_curves[-1]
        y_max = get_line_xy(upper_curve.line)[:, 1].max()
        # logger.debug("y_max:\n{}", y_max)
        h_critical = y_max - y_min
        # logger.debug("h_critical:\n{}", h_critical)
        return h_critical

    def plot(self, show: bool = True):
        unary_block = shops.unary_union(self.blocks).buffer(3)
        self.surface.linestring = self.surface.linestring.intersection(unary_block)
        self.surface.plot()
        for origin in self.origins.values():
            plot_points(origin, color=next(_colors))
        for curve in self.failure_curves:
            curve.plot()

        for normal in self.normals:
            plot_line(normal.intersection(unary_block), color='gray', ls='--', lw=1,
                      alpha=0.5)

        for partition in self.partitions:
            partition.plot()

        for block in self.blocks:
            plot_polygon(block, color=next(_colors))
        ax = plt.gca()
        ax.set_aspect('equal', 'box')
        tick_interval = 5
        x_ticks = np.arange(0, 25, tick_interval)
        y_ticks = np.arange(0, 25, tick_interval)

        ax.set_xticks(x_ticks)
        ax.set_yticks(y_ticks)

        # Set limits
        ax.set_xlim(0, 25)
        ax.set_ylim(0, 25)

        # Display grid for visualization
        ax.grid(True)
        if show:
            plt.show()

    @classmethod
    def from_trial(cls, trial: Trial | FixedTrial, config: dict) -> Self:
        surface = Surface(
            elev_bottom=5,
            elev_top=15,
            slope_angle=np.deg2rad(40),
            x_offset=5,
        )

        _origins = {}

        def _suggest_origin(idx, x, y):
            if config['same_origins']:
                if 'last' not in _origins:
                    _origins['last'] = suggest_origin(trial, idx, x, y)
                return _origins['last']
            else:
                return suggest_origin(trial, idx, x, y)

        case = cls(
            phita=np.deg2rad(23),
            soil_params=dict(
                gamma=18,
                cohesion=20,
                phita=np.deg2rad(30),
            ),
            surface=surface,
            origins={
                'first': shg.Point(-10, 25),
                'third': shg.Point(-5, 15),
            },
        )
        case.origins['first'] = _suggest_origin(1, [-15, 5], [5, 40])
        ratio1 = trial.suggest_float('normal_ratio_1', 0.2, 0.5)
        ratio2 = trial.suggest_float('normal_ratio_2', 0.55, 0.8)
        case.set_normals(ratios=[ratio1, ratio2])

        # curve_2_cls = eval(trial.suggest_categorical('curve_2_type', ['LinearCurve', 'LogSpiralCurve']))
        curve_2_cls = eval(config['curve_2_type'])
        if curve_2_cls == LinearCurve:
            curve_2 = LinearCurve(
                end_line=case.normals[1],
                angle=surface.slope_angle + np.deg2rad(
                    trial.suggest_float('curve_2_angle_offset', -20, 20)),
                end_x=big_num,
            )
        else:
            case.origins['second'] = _suggest_origin(2, [-15, 5], [5, 30])

            curve_2 = LogSpiralCurve(
                end_line=case.normals[1],
                phita=case.phita,
                origin=case.origins['second'],
                num_points=50,
            )

        curve_1 = LogSpiralCurve(
            end_line=case.normals[0],
            phita=case.phita,
            origin=case.origins['first'],
            num_points=60,
        )
        curve_2 = LinearCurve(
            end_line=case.normals[1],
            angle=surface.slope_angle + np.deg2rad(0),
            end_x=big_num,
        )
        curve_3 = LogSpiralCurve(
            end_line=surface.linestring,
            phita=case.phita,
            origin=case.origins['third'],
            num_points=30,
        )
        toe_offset = trial.suggest_float('toe_offset', -10, 0)
        case.set_failure_curves([curve_1, curve_2, curve_3], toe_offset=toe_offset)

        partition_1_params = dict(
            start=case.failure_curves[1].start,
            end_line=surface.linestring,
            angle=surface.slope_angle + np.deg2rad(90 + 20),
            end_x=-big_num,
        )
        partition_1_cls = eval(config['partition_1_type'])
        if partition_1_cls == PolynomialCurve:
            partition_1_params |= dict(
                depth=trial.suggest_float('partition_1_depth', 0.3, 3),
                side='left',
                num_points=20,
            )

        partition_2_params = dict(
            start=case.failure_curves[1].end_point,
            end_line=surface.linestring,
            angle=surface.slope_angle + np.deg2rad(90 - 15),
            end_x=-big_num,
        )
        # partition_2_cls = eval(trial.suggest_categorical('partition_2_type', ['LinearCurve', 'PolynomialCurve']))
        partition_2_cls = eval(config['partition_2_type'])
        if partition_2_cls == PolynomialCurve:
            partition_2_params |= dict(
                depth=trial.suggest_float('partition_2_depth', 0.3, 3),
                num_points=20,
            )
        case.set_partitions([
            partition_1_cls(**partition_1_params),
            partition_2_cls(**partition_2_params)])
        # case.set_partitions([
        #     LinearCurve(
        #         start=case.failure_curves[1].start,
        #         end_line=surface.linestring,
        #         angle=surface.slope_angle + np.deg2rad(90 + 20),
        #         end_x=-big_num,
        #     ),
        #     LinearCurve(
        #         start=case.failure_curves[1].end_point,
        #         end_line=surface.linestring,
        #         angle=surface.slope_angle + np.deg2rad(90 - 15),
        #         end_x=-big_num,
        #     ),
        # ])

        case.create_blocks()

        # surface.plot()
        # for normal in case.normals:
        #     plot_line(normal, color='gray', ls='--', lw=1, alpha=0.5)
        # case.plot()
        # plt.show()
        # sys.exit()
        energy_dissipation = case.calculate_energy_dissipation()
        external_work = case.calculate_external_work()
        return case

    def get_penalty(self) -> float:
        break_point_penalties = []
        for failure_curve1, failure_curve2 in mit.windowed(self.failure_curves, 2):
            c1_end = np.arctan(get_slope_tangent(failure_curve1.line, start=-2))
            # logger.debug("c1_end: {}", c1_end)
            c2_start = np.arctan(get_slope_tangent(failure_curve2.line, stop=2))
            # logger.debug("c2_start: {}", c2_start)
            penalty = abs(c1_end - c2_start)
            # logger.debug("penalty: {}", penalty)
            break_point_penalties.append(penalty)
        # logger.debug("break_point_penalties:\n{}", break_point_penalties)
        return (
                abs(self.energy_dissipation - self.external_work) /
                max(self.energy_dissipation, self.external_work)
        ) + sum(break_point_penalties)


def suggest_origin(trial: Trial | FixedTrial, idx: int, x: list[float],
                   y: list[float]) -> shg.Point:
    return shg.Point(
        trial.suggest_float(f'origin_{idx}_x', *x),
        trial.suggest_float(f'origin_{idx}_y', *y),
    )


class Optimizer(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    config: dict = Field(default_factory=dict)
    cases: dict = Field(default_factory=dict)
    sampler: optuna.samplers.BaseSampler
    n_trials: int
    n_jobs: int = 1
    storage_path: Path | str = 'db.sqlite'

    def objective_function(self, trial: Trial | FixedTrial) -> float:
        case = Case.from_trial(trial, self.config)

        trial.set_user_attr('energy_dissipation', case.energy_dissipation)
        trial.set_user_attr('external_work', case.external_work)
        trial.set_user_attr('h_critical', case.get_h_critical())

        self.cases[trial._trial_id] = case
        return case.get_penalty()

    def run(self):
        case_study = optuna.create_study(
            storage=f'sqlite:///{self.storage_path}',
            # study_name='reward_function_optimization2',
            # load_if_exists=True,
            # directions=['minimize'],
            sampler=self.sampler,
        )
        case_study.optimize(
            self.objective_function,
            n_trials=self.n_trials, n_jobs=self.n_jobs,
            catch=(ValueError, IndexError),
        )
        return case_study

    def plot(self, trial: FixedTrial):
        case = Case.from_trial(trial, self.config)
        logger.debug("case.energy_dissipation:\n{}", case.energy_dissipation)
        logger.debug("case.external_work:\n{}", case.external_work)
        case.plot()


def test_case(configs):
    sample_trial = FixedTrial(dict(
        origin_1_x=-5,
        origin_1_y=30,
        origin_2_x=0,
        origin_2_y=20,
        origin_3_x=0,
        origin_3_y=20,
        normal_position_1=0.35,
        normal_position_2=0.55,

        curve_2_angle_offset=0,

        partition_1_angle_offset=20,
        partition_2_angle_offset=-15,
        partition_1_depth=1,
        partition_2_depth=1,
    ))
    case = Case.from_trial(sample_trial, config=configs[0])
    case.get_penalty()
    case.plot()


def main():
    config_idx = 5
    configs = [
        # Case 1: different origins
        dict(
            partition_1_type='LinearCurve',
            partition_2_type='LinearCurve',
            curve_2_type='LinearCurve',
            same_origins=False,
        ),
        # Case 1: same origins
        dict(
            partition_1_type='LinearCurve',
            partition_2_type='LinearCurve',
            curve_2_type='LinearCurve',
            same_origins=True,
        ),
        # Case 2: different origins
        dict(
            partition_1_type='LinearCurve',
            partition_2_type='LinearCurve',
            curve_2_type='LogSpiralCurve',
            same_origins=False,
        ),
        # Case 3: different origins
        dict(
            partition_1_type='PolynomialCurve',
            partition_2_type='PolynomialCurve',
            curve_2_type='LinearCurve',
            same_origins=False,
        ),
        # Case 3: same origins
        dict(
            partition_1_type='PolynomialCurve',
            partition_2_type='PolynomialCurve',
            curve_2_type='LinearCurve',
            same_origins=True,
        ),
        # Case 4: different origins
        dict(
            partition_1_type='PolynomialCurve',
            partition_2_type='PolynomialCurve',
            curve_2_type='LogSpiralCurve',
            same_origins=False,
        ),
    ]
    # trial = FixedTrial(
    #     {'origin_1_x': -0.23074857327928022, 'origin_1_y': 37.014837675681676,
    #      'normal_ratio_1': 0.2317734071776802, 'normal_ratio_2': 0.7998553388853996,
    #      'origin_2_x': 1.7698577310435422, 'origin_2_y': 14.47683670895816,
    #      'partition_1_depth': 2.16799367073377, 'partition_2_depth': 2.540524972461388})

    trial = FixedTrial(
        {'origin_1_x': -7.953707269568891, 'origin_1_y': 29.843102949107095,
         'normal_ratio_1': 0.4990555034187145, 'normal_ratio_2': 0.5662166268467204,
         'origin_2_x': 1.484739865236886, 'origin_2_y': 27.302551742068104}
    )
    # case = Case.from_trial(trial, config=configs[config_idx])
    # penalty = case.get_penalty()
    # logger.debug("penalty: {}", penalty)
    # case.plot()
    # return
    # test_case(configs)
    # return

    optimizer = Optimizer(
        config=configs[config_idx],
        sampler=optuna.samplers.TPESampler(
            n_startup_trials=10,
            # seed=369,
        ),
        n_trials=50,
        n_jobs=1,
    )
    case_study = optimizer.run()
    logger.debug("case_study.best_trial:\n{}", case_study.best_trial)
    logger.debug("case_study.best_params:\n{}", case_study.best_params)
    logger.debug("case_study.best_value:\n{}", case_study.best_value)
    trials_data: pd.DataFrame = case_study.trials_dataframe()
    logger.debug("trials_data:\n{}", trials_data)
    now = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    trials_data.to_csv(f'trials_data__config_idx={config_idx}__{now}.csv')
    optimizer.plot(case_study.best_trial)

    pass


if __name__ == '__main__':
    main()
